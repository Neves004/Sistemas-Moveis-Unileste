import { StyleSheet, View, Image, Text, ScrollView } from 'react-native';
import { styles } from './styles';
import { Button } from '@/components/Button';
import { Input } from '@/components/Input';
import { Filter } from '@/components/Filter';
import { FilterStatus } from '@/types/FilterStatus';
import { Card } from '@/components/Card';
import { Search } from "lucide-react-native";

export default function Home() {
  return (

    <View style={styles.container}>1
      <View style={styles.flex}>
        <View style={styles.paddingLeft}>
          <Text style={styles.h1}>Orçamentos</Text>
          <Text style={styles.text}> Você tem 1 item em rascunho </Text>
        </View>
        <View style={styles.right}>
          <Button title="+ Novo" />
        </View>
      </View>


      <View style={styles.form}>
        <View style={styles.inputArea}>
          <Search style={styles.searchIcon} color="#aaa" size={20} />
          <Input style={styles.input} placeholder="Título ou cliente"/>

        </View>
      </View>

      <ScrollView style={styles.content}>

        <Card title='Desenvolvimento de aplicativo de loja online' status={FilterStatus.APROVADO} valor={1200} desc={'Soluções Tecnologicas Beta'}></Card>
        <Card title='Desenvolvimento de aplicativo de loja online' status={FilterStatus.APROVADO} valor={1200} desc={'Soluções Tecnologicas Beta'}></Card>
        <Card title='Desenvolvimento de aplicativo de loja online' status={FilterStatus.APROVADO} valor={1200} desc={'Soluções Tecnologicas Beta'}></Card>
        <Card title='Desenvolvimento de aplicativo de loja online' status={FilterStatus.APROVADO} valor={1200} desc={'Soluções Tecnologicas Beta'}></Card>
        <Card title='Desenvolvimento de aplicativo de loja online' status={FilterStatus.APROVADO} valor={1200} desc={'Soluções Tecnologicas Beta'}></Card>
        <Card title='Desenvolvimento de aplicativo de loja online' status={FilterStatus.APROVADO} valor={1200} desc={'Soluções Tecnologicas Beta'}></Card>
        <Card title='Desenvolvimento de aplicativo de loja online' status={FilterStatus.APROVADO} valor={1200} desc={'Soluções Tecnologicas Beta'}></Card>
        <Card title='Desenvolvimento de aplicativo de loja online' status={FilterStatus.APROVADO} valor={1200} desc={'Soluções Tecnologicas Beta'}></Card>

      </ScrollView>
    </View>
  );

}
